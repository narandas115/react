// import logo from './logo.svg';
import './App.css';
import RootRoutes from './RoutingModule/RootRoutes';
function App() {
  return (
    <div>
      <RootRoutes/>
    </div>
  );
}

export default App;