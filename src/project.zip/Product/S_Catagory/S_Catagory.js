import React from 'react';

export default function S_Catagory() {
  return <div></div>;
}

