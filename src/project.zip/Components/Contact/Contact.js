import React from 'react'

function Contact() {
    return (
        <div>
            <h1>Please enter your Contact,Our exicutive will contact you soon</h1>
        </div>
    )
}

export default Contact
