import React from 'react'
import './Home.css'

function Home() {
    return (
        <div className='homePage' >
            <h1>Welcome to My Home Page</h1>
        </div>
    )
}

export default Home
