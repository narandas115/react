import React from 'react'
import {Route,Routes,BrowserRouter as Router} from 'react-router-dom'
import About from '../Components/About/About'
import Home from '../Components/Home/Home'
import Contact from '../Components/Contact/Contact'
import Feedback from '../Components/Feedback/Feedback'
import Pnf from '../Components/Pnf/Pnf'
import Header from '../Layout/Header'
import T_Cat from '../Topics/T_Cat/T_Cat'
import T_SubCat from '../Topics/T_SubCat/T_SubCat'
import Register from '../Authentication/Registration/Register'
import Login from '../Authentication/Login/Login'
import T_Details from '../Topics/T_Details/T_Details'


export const RootRoutes = () => {
    return (
        <Router>
            <Header />
            <Routes>
                <Route path="" element={<Home />} /> {/*Default path setup*/}
                <Route path="about_page" element={<About />} />
                <Route path="contact_page/:name" element={<Contact />} />
                <Route path="feedback_page" element={<Feedback />} />
                
                <Route path="topics" element={<T_Cat/>}/>
                <Route path="subcat/:tid" element={<T_SubCat />} />
                <Route path="details/:tid/:sid" element={<T_Details/>}/>
               
                <Route path="*" element={<Pnf />} />
                <Route path="register_page" element={<Register />} />
                <Route path="login_page"element={<Login/>}/>
            </Routes>
        </Router>
    )
}

export default RootRoutes